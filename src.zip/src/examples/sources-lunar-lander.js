export default [
    {
        name:'player',
        type: 'texture',
        path: '../assets/player/spaceship.png'
    }, 
    {
        name:'ground',
        type: 'texture',
        path: '../assets/ground/dirt.png'
    },
    {
        name:'background',
        type: 'texture',
        path: '../assets/background/stars.png'
    },
    
]    
